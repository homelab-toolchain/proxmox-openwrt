
const cbi_d=[];if(typeof window!=='undefined')
window.cbi_d=cbi_d;const cbi_strings={path:{},label:{}};if(typeof window!=='undefined')
window.cbi_strings=cbi_strings;function s8(bytes,off){const n=bytes[off];return(n>0x7F)?(n-256)>>>0:n;}
function u16(bytes,off){return((bytes[off+1]<<8)+bytes[off])>>>0;}
function sfh(s){if(s===null||s.length===0)
return null;const bytes=[];for(let i=0;i<s.length;i++){let ch=s.charCodeAt(i);if(ch>=0xD800&&ch<=0xDBFF&&i+1<s.length){const next=s.charCodeAt(i+1);if(next>=0xDC00&&next<=0xDFFF){ch=0x10000+((ch-0xD800)<<10)+(next-0xDC00);i++;}}
if(ch<=0x7F)
bytes.push(ch);else if(ch<=0x7FF)
bytes.push(((ch>>>6)&0x1F)|0xC0,(ch&0x3F)|0x80);else if(ch<=0xFFFF)
bytes.push(((ch>>>12)&0x0F)|0xE0,((ch>>>6)&0x3F)|0x80,(ch&0x3F)|0x80);else if(ch<=0x10FFFF)
bytes.push(((ch>>>18)&0x07)|0xF0,((ch>>>12)&0x3F)|0x80,((ch>>6)&0x3F)|0x80,(ch&0x3F)|0x80);}
if(!bytes.length)
return null;let hash=(bytes.length>>>0);let len=(bytes.length>>>2);let off=0,tmp;while(len--){hash+=u16(bytes,off);tmp=((u16(bytes,off+2)<<11)^hash)>>>0;hash=((hash<<16)^tmp)>>>0;hash+=hash>>>11;off+=4;}
switch((bytes.length&3)>>>0){case 3:hash+=u16(bytes,off);hash=(hash^(hash<<16))>>>0;hash=(hash^(s8(bytes,off+2)<<18))>>>0;hash+=hash>>>11;break;case 2:hash+=u16(bytes,off);hash=(hash^(hash<<11))>>>0;hash+=hash>>>17;break;case 1:hash+=s8(bytes,off);hash=(hash^(hash<<10))>>>0;hash+=hash>>>1;break;}
hash=(hash^(hash<<3))>>>0;hash+=hash>>>5;hash=(hash^(hash<<4))>>>0;hash+=hash>>>17;hash=(hash^(hash<<25))>>>0;hash+=hash>>>6;return(0x100000000+hash).toString(16).slice(1);}
var plural_function=null;function trimws(s){return String(s).trim().replace(/[ \t\n]+/g,' ');}
function _(s,c){var k=(c!=null?trimws(c)+'\u0001':'')+trimws(s);return(window.TR&&TR[sfh(k)])||s;}
function N_(n,s,p,c){if(plural_function==null&&window.TR)
plural_function=new Function('n',(TR['00000000']||'plural=(n != 1);')+'return +plural');var i=plural_function?plural_function(n):(n!=1),k=(c!=null?trimws(c)+'\u0001':'')+trimws(s)+'\u0002'+i.toString();return(window.TR&&TR[sfh(k)])||(i?p:s);}
function cbi_d_add(field,dep,index){var obj=(typeof(field)==='string')?document.getElementById(field):field;if(obj){var entry
for(var i=0;i<cbi_d.length;i++){if(cbi_d[i].id==obj.id){entry=cbi_d[i];break;}}
if(!entry){entry={"node":obj,"id":obj.id,"parent":obj.parentNode.id,"deps":[],"index":index};cbi_d.unshift(entry);}
entry.deps.push(dep)}}
function cbi_d_checkvalue(target,ref){var value=null,query='input[id="'+target+'"], input[name="'+target+'"], '+'select[id="'+target+'"], select[name="'+target+'"]';document.querySelectorAll(query).forEach(function(i){if(value===null&&((i.type!=='radio'&&i.type!=='checkbox')||i.checked===true))
value=i.value;});return(((value!==null)?value:"")==ref);}
function cbi_d_check(deps){var reverse;var def=false;for(var i=0;i<deps.length;i++){var istat=true;reverse=false;for(var j in deps[i]){if(j=="!reverse"){reverse=true;}else if(j=="!default"){def=true;istat=false;}else{istat=(istat&&cbi_d_checkvalue(j,deps[i][j]))}}
if(istat^reverse){return true;}}
return def;}
function cbi_d_update(){var state=false;for(var i=0;i<cbi_d.length;i++){var entry=cbi_d[i];var node=document.getElementById(entry.id);var parent=document.getElementById(entry.parent);if(node&&node.parentNode&&!cbi_d_check(entry.deps)){node.parentNode.removeChild(node);state=true;}
else if(parent&&(!node||!node.parentNode)&&cbi_d_check(entry.deps)){var next=undefined;for(next=parent.firstChild;next;next=next.nextSibling){if(next.getAttribute&&parseInt(next.getAttribute('data-index'),10)>entry.index)
break;}
if(!next)
parent.appendChild(entry.node);else
parent.insertBefore(entry.node,next);state=true;}
if(parent&&parent.parentNode&&parent.getAttribute('data-optionals'))
parent.parentNode.style.display=(parent.options.length<=1)?'none':'';}
if(entry&&entry.parent)
cbi_tag_last(parent);if(state)
cbi_d_update();else if(parent)
parent.dispatchEvent(new CustomEvent('dependency-update',{bubbles:true}));}
function cbi_init(){let nodes;document.querySelectorAll('.cbi-dropdown').forEach(function(node){cbi_dropdown_init(node);node.addEventListener('cbi-dropdown-change',cbi_d_update);});nodes=document.querySelectorAll('[data-strings]');for(let n of nodes){const str=JSON.parse(n.getAttribute('data-strings'));for(let key in str){for(let key2 in str[key]){const dst=cbi_strings[key]||(cbi_strings[key]={});dst[key2]=str[key][key2];}}}
nodes=document.querySelectorAll('[data-depends]');for(let n of nodes){const index=parseInt(n.getAttribute('data-index'),10);const depends=JSON.parse(n.getAttribute('data-depends'));if(!isNaN(index)&&depends.length>0){for(let a of depends)
cbi_d_add(n,a,index);}}
nodes=document.querySelectorAll('[data-update]');for(let n of nodes){const events=n.getAttribute('data-update').split(' ');for(let ev of events)
n.addEventListener(ev,cbi_d_update);}
nodes=document.querySelectorAll('[data-choices]');for(let node of nodes){const choices=JSON.parse(node.getAttribute('data-choices'));const options={};for(let j=0;j<choices[0].length;j++)
options[choices[0][j]]=choices[1][j];const def=(node.getAttribute('data-optional')==='true')?node.placeholder||'':null;const cb=new L.ui.Combobox(node.value,options,{name:node.getAttribute('name'),sort:choices[0],select_placeholder:def||_('-- Please choose --'),custom_placeholder:node.getAttribute('data-manual')||_('-- custom --')});const n=cb.render();n.addEventListener('cbi-dropdown-change',cbi_d_update);node.parentNode.replaceChild(n,node);}
nodes=document.querySelectorAll('[data-dynlist]');for(let node of nodes){const choices=JSON.parse(node.getAttribute('data-dynlist'));const values=JSON.parse(node.getAttribute('data-values')||'[]');let options=null;if(choices[0]&&choices[0].length){options={};for(let j=0;j<choices[0].length;j++)
options[choices[0][j]]=choices[1][j];}
let dl=new L.ui.DynamicList(values,options,{name:node.getAttribute('data-prefix'),sort:choices[0],datatype:choices[2],optional:choices[3],placeholder:node.getAttribute('data-placeholder')});let n=dl.render();n.addEventListener('cbi-dynlist-change',cbi_d_update);node.parentNode.replaceChild(n,node);}
nodes=document.querySelectorAll('[data-type]');for(let node of nodes){cbi_validate_field(node,node.getAttribute('data-optional')==='true',node.getAttribute('data-type'));}
document.querySelectorAll('.cbi-tooltip:not(:empty)').forEach(function(s){s.parentNode.classList.add('cbi-tooltip-container');});document.querySelectorAll('.cbi-section-remove > input[name^="cbi.rts"]').forEach(function(i){let handler=function(ev){var bits=this.name.split(/\./),section=document.getElementById('cbi-'+bits[2]+'-'+bits[3]);section.style.opacity=(ev.type==='mouseover')?0.5:'';};i.addEventListener('mouseover',handler);i.addEventListener('mouseout',handler);});var tasks=[];document.querySelectorAll('[data-ui-widget]').forEach(function(node){const args=JSON.parse(node.getAttribute('data-ui-widget')||'[]');const widget=new(Function.prototype.bind.apply(L.ui[args[0]],args));const markup=widget.render();tasks.push(Promise.resolve(markup).then(function(markup){markup.addEventListener('widget-change',cbi_d_update);node.parentNode.replaceChild(markup,node);}));});Promise.all(tasks).then(cbi_d_update);}
function cbi_validate_form(form,errmsg)
{if(form.cbi_state=='add-section'||form.cbi_state=='del-section')
return true;if(form.cbi_validators){for(let fv of form.cbi_validators){const validator=fv;if(!validator()&&errmsg){if(typeof window!=='undefined'&&typeof window.alert==='function')
window.alert(errmsg);return false;}}}
return true;}
function cbi_validate_named_section_add(input)
{var button=input.parentNode.parentNode.querySelector('.cbi-button-add');button.disabled=input.value==='';}
function cbi_validate_reset(form)
{window.setTimeout(function(){cbi_validate_form(form,null)},100);return true;}
function cbi_validate_field(cbid,optional,type)
{var field=isElem(cbid)?cbid:document.getElementById(cbid);var validatorFn;try{var cbiValidator=L.validation.create(field,type,optional);validatorFn=cbiValidator.validate.bind(cbiValidator);}
catch(e){validatorFn=null;};if(validatorFn!==null){var form=findParent(field,'form');if(!form.cbi_validators)
form.cbi_validators=[];form.cbi_validators.push(validatorFn);field.addEventListener("blur",validatorFn);field.addEventListener("keyup",validatorFn);field.addEventListener("cbi-dropdown-change",validatorFn);if(matchesElem(field,'select')){field.addEventListener("change",validatorFn);field.addEventListener("click",validatorFn);}
validatorFn();}}
function cbi_row_swap(elem,up,store)
{var tr=findParent(elem.parentNode,'.cbi-section-table-row');if(!tr)
return false;tr.classList.remove('flash');if(up){var prev=tr.previousElementSibling;if(prev&&prev.classList.contains('cbi-section-table-row'))
tr.parentNode.insertBefore(tr,prev);else
return;}
else{var next=tr.nextElementSibling?tr.nextElementSibling.nextElementSibling:null;if(next&&next.classList.contains('cbi-section-table-row'))
tr.parentNode.insertBefore(tr,next);else if(!next)
tr.parentNode.appendChild(tr);else
return;}
var ids=[];for(var i=0,n=0;i<tr.parentNode.childNodes.length;i++){var node=tr.parentNode.childNodes[i];if(node.classList&&node.classList.contains('cbi-section-table-row')){node.classList.remove('cbi-rowstyle-1');node.classList.remove('cbi-rowstyle-2');node.classList.add((n++%2)?'cbi-rowstyle-2':'cbi-rowstyle-1');if(/-([^-]+)$/.test(node.id))
ids.push(RegExp.$1);}}
var input=document.getElementById(store);if(input)
input.value=ids.join(' ');window.scrollTo(0,tr.offsetTop);void tr.offsetWidth;tr.classList.add('flash');return false;}
function cbi_tag_last(container)
{let last;for(let cn of container.childNodes){var c=cn;if(matchesElem(c,'div')){c.classList.remove('cbi-value-last');last=c;}}
if(last)
last.classList.add('cbi-value-last');}
function cbi_submit(elem,name,value,action)
{const form=elem.form||findParent(elem,'form');if(!form)
return false;if(action)
form.action=action;if(name){var hidden=form.querySelector('input[type="hidden"][name="%s"]'.format(name))||E('input',{type:'hidden',name:name});hidden.value=value||'1';form.appendChild(hidden);}
form.submit();return true;}
String.prototype.format=function()
{if(!RegExp)
return;const html_esc=[/&/g,'&#38;',/"/g,'&#34;',/'/g,'&#39;',/</g,'&#60;',/>/g,'&#62;'];const quot_esc=[/"/g,'&#34;',/'/g,'&#39;'];function esc(s,r){const t=typeof(s);if(s==null||t==='object'||t==='function')
return'';if(t!=='string')
s=String(s);for(let i=0;i<r.length;i+=2)
s=s.replace(r[i],r[i+1]);return s;}
let str=this;let subst,n,pad;let out='';const re=/^(([^%]*)%('.|0|\x20)?(-)?(\d+)?(\.\d+)?(%|b|c|d|u|f|o|s|x|X|q|h|j|t|m))/;let a=[],numSubstitutions=0;while((a=re.exec(str))!==null){const m=a[1];let leftpart=a[2],pPad=a[3],pJustify=a[4],pMinLength=a[5];let pPrecision=a[6],pType=a[7];let precision;if(pType=='%'){subst='%';}
else{if(numSubstitutions<arguments.length){let param=arguments[numSubstitutions++];pad='';if(pPad&&pPad.substr(0,1)=="'")
pad=pPad.substr(1,1);else if(pPad)
pad=pPad;else
pad=' ';precision=-1;if(pPrecision&&pType=='f')
precision=+pPrecision.substring(1);subst=param;switch(pType){case'b':subst=Math.floor(+param||0).toString(2);break;case'c':subst=String.fromCharCode(+param||0);break;case'd':subst=Math.floor(+param||0).toFixed(0);break;case'u':n=+param||0;subst=Math.floor((n<0)?0x100000000+n:n).toFixed(0);break;case'f':subst=(precision>-1)?((+param||0.0)).toFixed(precision):(+param||0.0);break;case'o':subst=Math.floor(+param||0).toString(8);break;case's':subst=param;break;case'x':subst=Math.floor(+param||0).toString(16).toLowerCase();break;case'X':subst=Math.floor(+param||0).toString(16).toUpperCase();break;case'h':subst=esc(param,html_esc);break;case'q':subst=esc(param,quot_esc);break;case't':var td=0;var th=0;var tm=0;var ts=(param||0);if(ts>59){tm=Math.floor(ts/60);ts=(ts%60);}
if(tm>59){th=Math.floor(tm/60);tm=(tm%60);}
if(th>23){td=Math.floor(th/24);th=(th%24);}
subst=(td>0)?String.format('%dd %dh %dm %ds',td,th,tm,ts):String.format('%dh %dm %ds',th,tm,ts);break;case'm':var mf=pMinLength?+pMinLength:1000;var pr=pPrecision?~~(10* +('0'+pPrecision)):2;var i=0;var val=(+param||0);var units=[' ',' K',' M',' G',' T',' P',' E'];for(i=0;(i<units.length)&&(val>mf);i++)
val/=mf;if(i)
subst=val.toFixed(pr)+units[i]+(mf==1024?'i':'');else
subst=val+' ';pMinLength=null;break;}}}
if(pMinLength){subst=subst.toString();for(let i=subst.length;i<pMinLength;i++)
if(pJustify=='-')
subst=subst+' ';else
subst=pad+subst;}
out+=leftpart+subst;str=str.substr(m.length);}
return out+str;}
String.prototype.nobr=function()
{return this.replace(/[\s\n]+/g,'&#160;');}
String.format=function()
{const a=[];for(let i=1;i<arguments.length;i++){a.push(arguments[i]);}
return''.format.apply(arguments[0],a);}
String.nobr=function()
{const a=[];for(let i=1;i<arguments.length;i++)
a.push(arguments[i]);return''.nobr.apply(arguments[0],a);}
if(window.NodeList&&!NodeList.prototype.forEach){NodeList.prototype.forEach=function(callback,thisArg){thisArg=thisArg||window;for(var i=0;i<this.length;i++){callback.call(thisArg,this[i],i,this);}};}
if(!window.requestAnimationFrame){window.requestAnimationFrame=function(f){window.setTimeout(function(){f(new Date().getTime())},1000/30);};}
function isElem(e){return L.dom.elem(e)}
function matchesElem(node,selector){return L.dom.matches(node,selector)}
function findParent(node,selector){return L.dom.parent(node,selector)}
function E(){return L.dom.create.apply(L.dom,arguments)}
function cbi_dropdown_init(sb){if(sb&&L.dom.findClassInstance(sb)instanceof L.ui.Dropdown)
return;const dl=new L.ui.Dropdown(sb,null,{name:sb.getAttribute('name')});return dl.bind(sb);}
function cbi_update_table(table,data,placeholder){const target=isElem(table)?table:document.querySelector(table);if(!isElem(target))
return;let t=L.dom.findClassInstance(target);if(!(t instanceof L.ui.Table)){t=new L.ui.Table(target);L.dom.bindClassInstance(target,t);}
t.update(data,placeholder);}
document.addEventListener('DOMContentLoaded',function(){document.addEventListener('validation-failure',function(ev){if(ev.target===document.activeElement)
L.showTooltip(ev);});document.addEventListener('validation-success',function(ev){if(ev.target===document.activeElement)
L.hideTooltip(ev);});L.require('ui').then(function(ui){document.querySelectorAll('.table').forEach(cbi_update_table);});});